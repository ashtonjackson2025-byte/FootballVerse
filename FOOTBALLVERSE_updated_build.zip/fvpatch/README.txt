# FOOTBALLVERSE complete app files

## Install
1. Stop the Vite server in the terminal with `Ctrl + C`.
2. Extract this ZIP.
3. Copy `src/App.jsx` and `src/App.css` into your project's `src` folder, replacing the old files.
4. Replace `vite.config.js` in the project root with the one in this ZIP.
5. Keep your existing `.env.local` file and API key. Do not share it.
6. Run `npm run dev` and open the localhost URL Vite prints.

## Included
- Dashboard and competition navigation
- Real league tables and fixtures through football-data.org where your API plan permits
- Score predictions saved in local storage
- Simulated table calculated from finished scores and your predictions
- Matchday fixture groups
- Cups and European competition pages
- JSON dataset importer for competitions not included in your API plan
- History snapshots, season label, backup export and universe reset

## Dataset import format
The Settings page includes a copyable example. A competition needs:
- `id`, `name`, `teams`, `matches`
- Each team: `id`, `name`
- Each match: `id`, `date`, `status`, `homeId`, `home`, `awayId`, `away`
- Optional `homeScore` and `awayScore` for finished matches

Use `status: "FINISHED"` for completed matches and `status: "SCHEDULED"` for future matches.

## Important data limits
The football-data.org free plan does not provide every English non-league division or every domestic cup dataset. This app does not invent those fixtures. Import a verified dataset for those competitions. The Vite proxy protects the token from browser-side code during local development only; do not deploy this development proxy as a production API.
