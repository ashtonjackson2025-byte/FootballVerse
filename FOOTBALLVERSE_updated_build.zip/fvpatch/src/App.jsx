import { useEffect, useMemo, useState } from 'react'
import './App.css'

const API = '/api/football-data'
const STORAGE = 'footballverse-complete-v1'
const DEFAULT_COMPS = [
  { code: 'PL', name: 'Premier League', country: 'England', type: 'League' },
  { code: 'ELC', name: 'Championship', country: 'England', type: 'League' },
  { code: 'CL', name: 'Champions League', country: 'Europe', type: 'Europe' },
  { code: 'EL', name: 'Europa League', country: 'Europe', type: 'Europe' },
]
const NAV = ['Dashboard', 'Leagues', 'Fixtures', 'Cups', 'Europe', 'History', 'Settings']
const EMPTY = { predictions: {}, customCompetitions: [], customMatches: [], history: [], season: '2026/27' }

function loadStore() {
  try { return { ...EMPTY, ...JSON.parse(localStorage.getItem(STORAGE) || '{}') } }
  catch { return EMPTY }
}
function saveStore(value) { localStorage.setItem(STORAGE, JSON.stringify(value)) }
function dateLabel(value) {
  if (!value) return 'Date TBC'
  return new Date(value).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
}
function score(match) {
  return `${match.score?.fullTime?.home ?? '-'} - ${match.score?.fullTime?.away ?? '-'}`
}
function calcTable(teams, matches, predictions) {
  const rows = new Map()
  teams.forEach(t => rows.set(t.id, { id: t.id, name: t.name, played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, gd: 0, points: 0 }))
  matches.forEach(m => {
    let h, a
    if (m.status === 'FINISHED') {
      h = m.score?.fullTime?.home; a = m.score?.fullTime?.away
    } else {
      const p = predictions[m.id]
      if (!p || p.home === '' || p.away === '') return
      h = Number(p.home); a = Number(p.away)
    }
    if (!Number.isFinite(h) || !Number.isFinite(a)) return
    const home = rows.get(m.homeTeam.id), away = rows.get(m.awayTeam.id)
    if (!home || !away) return
    home.played++; away.played++
    home.gf += h; home.ga += a; away.gf += a; away.ga += h
    if (h > a) { home.won++; away.lost++; home.points += 3 }
    else if (h < a) { away.won++; home.lost++; away.points += 3 }
    else { home.drawn++; away.drawn++; home.points++; away.points++ }
  })
  return [...rows.values()].map(r => ({ ...r, gd: r.gf - r.ga }))
    .sort((a,b) => b.points-a.points || b.gd-a.gd || b.gf-a.gf || a.name.localeCompare(b.name))
}
function zoneClass(code, pos) {
  if (code === 'PL') return pos <= 4 ? 'zone-blue' : pos === 5 ? 'zone-green' : pos >= 18 ? 'zone-red' : ''
  if (code === 'CL' || code === 'EL') return pos <= 8 ? 'zone-green' : pos <= 24 ? 'zone-blue' : 'zone-red'
  return ''
}
function parseImportedData(raw) {
  const data = JSON.parse(raw)
  if (!data || !Array.isArray(data.competitions)) throw new Error('JSON needs a competitions array.')
  data.competitions.forEach(c => {
    if (!c.id || !c.name || !Array.isArray(c.teams) || !Array.isArray(c.matches)) throw new Error('Each competition needs id, name, teams and matches.')
  })
  return data
}

export default function App() {
  const [store, setStore] = useState(loadStore)
  const [page, setPage] = useState('Dashboard')
  const [competitions, setCompetitions] = useState(DEFAULT_COMPS)
  const [selected, setSelected] = useState('PL')
  const [apiData, setApiData] = useState({})
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [tab, setTab] = useState('real')
  const [notice, setNotice] = useState('')
  const [importText, setImportText] = useState('')
  const [showImport, setShowImport] = useState(false)
  const [started, setStarted] = useState(() => localStorage.getItem('footballverse-started') === 'yes')

  useEffect(() => saveStore(store), [store])
  const current = competitions.find(c => c.code === selected) || competitions[0]
  const data = apiData[selected] || {}
  const customComp = store.customCompetitions.find(c => c.code === selected)
  const matches = customComp ? store.customMatches.filter(m => m.competitionCode === selected) : (data.matches || [])
  const teams = customComp ? customComp.teams : (data.teams || [])
  const realTable = data.standings?.[0]?.table || []
  const simulatedTable = useMemo(() => calcTable(teams.map(t => ({ id: t.id, name: t.name })), matches, store.predictions), [teams, matches, store.predictions])
  const finished = matches.filter(m => m.status === 'FINISHED').length
  const upcoming = matches.filter(m => m.status !== 'FINISHED').length
  const predictionCount = Object.keys(store.predictions).length

  async function loadCompetition(code = selected) {
    const comp = competitions.find(c => c.code === code)
    if (!comp || comp.custom) return
    setLoading(true); setError('')
    try {
      const [standingsRes, matchesRes] = await Promise.all([
        fetch(`${API}/competitions/${code}/standings`),
        fetch(`${API}/competitions/${code}/matches?season=2026`)
      ])
      const [standingsJson, matchesJson] = await Promise.all([standingsRes.json(), matchesRes.json()])
      if (!standingsRes.ok && !matchesRes.ok) throw new Error(standingsJson.message || matchesJson.message || 'The data provider rejected this competition.')
      setApiData(prev => ({ ...prev, [code]: { standings: standingsJson.standings || [], matches: matchesJson.matches || [], teams: (standingsJson.standings?.[0]?.table || []).map(r => r.team) } }))
    } catch (e) { setError(`${e.message}. Check your API plan or connection.`) }
    finally { setLoading(false) }
  }
  useEffect(() => { if (!current?.custom) loadCompetition(selected) }, [selected, competitions.length])

  function setPrediction(id, side, value) {
    if (value !== '' && (!/^\d{1,2}$/.test(value) || Number(value) > 99)) return
    setStore(s => ({ ...s, predictions: { ...s.predictions, [id]: { ...(s.predictions[id] || { home: '', away: '' }), [side]: value } } }))
  }
  function clearPrediction(id) {
    setStore(s => { const next = { ...s.predictions }; delete next[id]; return { ...s, predictions: next } })
  }
  function simulateSeason() {
    const snapshot = { date: new Date().toISOString(), season: store.season, competition: current?.name || 'Universe', table: simulatedTable }
    setStore(s => ({ ...s, history: [snapshot, ...s.history] }))
    setNotice('Season snapshot saved to History.')
  }
  function resetUniverse() {
    if (!window.confirm('Reset all predictions, imported competitions and history? This cannot be undone.')) return
    setStore(EMPTY); setNotice('Universe reset.')
  }
  function importDataset() {
    try {
      const parsed = parseImportedData(importText)
      const comps = parsed.competitions.map(c => ({ code: c.id, name: c.name, country: c.country || 'Custom', type: c.type || 'League', custom: true }))
      const importedMatches = parsed.competitions.flatMap(c => c.matches.map((m, i) => ({
        id: String(m.id || `${c.id}-${i}`), competitionCode: c.id, utcDate: m.date || null, status: m.status || 'SCHEDULED',
        homeTeam: { id: m.homeId, name: m.home }, awayTeam: { id: m.awayId, name: m.away },
        score: { fullTime: { home: m.homeScore ?? null, away: m.awayScore ?? null } }
      })))
      setStore(s => ({ ...s, customCompetitions: [...s.customCompetitions.filter(c => !comps.some(n => n.code === c.code)), ...parsed.competitions.map(c => ({ code: c.id, name: c.name, teams: c.teams }))], customMatches: [...s.customMatches.filter(m => !comps.some(c => c.code === m.competitionCode)), ...importedMatches] }))
      setCompetitions(prev => [...prev.filter(c => !comps.some(n => n.code === c.code)), ...comps])
      setSelected(comps[0].code); setShowImport(false); setImportText(''); setNotice('Dataset imported successfully.')
    } catch (e) { setNotice(`Import failed: ${e.message}`) }
  }
  function exportData() {
    const blob = new Blob([JSON.stringify(store, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob); const a = document.createElement('a')
    a.href = url; a.download = 'footballverse-backup.json'; a.click(); URL.revokeObjectURL(url)
  }

  const matchdays = useMemo(() => {
    const groups = new Map()
    matches.slice().sort((a,b) => new Date(a.utcDate || 0)-new Date(b.utcDate || 0)).forEach(m => {
      const key = m.matchday ? `Matchday ${m.matchday}` : dateLabel(m.utcDate)
      if (!groups.has(key)) groups.set(key, [])
      groups.get(key).push(m)
    })
    return [...groups.entries()]
  }, [matches])

  if (!started) return <div className="welcome-screen"><button className="get-started" onClick={() => { localStorage.setItem('footballverse-started', 'yes'); setStarted(true) }}>Get started.</button></div>

  return <div className="workspace-layout">
    <aside className="contents-rail">
      <div className="name-block"><span className="brand-ball">●</span><span>FOOTBALL<span>VERSE</span></span></div>
      <div className="contents-block"><span className="rail-heading">CONTENTS / THINGS</span>
        {NAV.filter(item => item !== 'Leagues').map(item => <button key={item} className={`rail-link ${page === item ? 'active' : ''}`} onClick={() => setPage(item)}>{item}</button>)}
      </div>
      <div className="rail-season"><span className="live-dot"/> {store.season}</div>
    </aside>
    <aside className="leagues-rail">
      <div className="leagues-card"><span className="rail-heading">LEAGUES</span>
        {competitions.filter(c => c.type === 'League').map(c => <button key={c.code} className={`league-link ${selected === c.code ? 'active' : ''}`} onClick={() => { setSelected(c.code); setPage('Leagues') }}>{c.name}</button>)}
        <span className="rail-heading extra-heading">EUROPE</span>
        {competitions.filter(c => c.type === 'Europe').map(c => <button key={c.code} className={`league-link ${selected === c.code ? 'active' : ''}`} onClick={() => { setSelected(c.code); setPage('Europe') }}>{c.name}</button>)}
        <button className="add-league" onClick={() => { setPage('Settings'); setShowImport(true) }}>+ Import competition</button>
      </div>
    </aside>
    <main className="main">
      <header className="topbar"><div><span className="eyebrow">THE FOOTBALL UNIVERSE</span><h1>{page}</h1></div><div className="top-actions"><span className="season-chip">{store.season}</span><button className="icon-btn" onClick={exportData} title="Export backup">↧</button></div></header>
      {notice && <button className="notice" onClick={() => setNotice('')}>{notice} <b>×</b></button>}
      {page === 'Dashboard' && <section>
        <div className="hero"><div><span className="eyebrow">YOUR WORLD. YOUR RESULTS.</span><h2>Every match.<br/><em>One universe.</em></h2><p>Track real football, make predictions and build your own alternate history.</p><button className="primary-btn" onClick={() => setPage('Fixtures')}>Explore fixtures <span>↗</span></button></div><div className="hero-mark">FV<span>27</span></div></div>
        <div className="stats-grid"><Stat label="COMPETITIONS" value={competitions.length} detail="Loaded competitions"/><Stat label="MATCHES PLAYED" value={finished} detail="In selected competition"/><Stat label="UPCOMING" value={upcoming} detail="Awaiting a result"/><Stat label="PREDICTIONS" value={predictionCount} detail="Saved across universe"/></div>
        <div className="section-heading"><div><span className="eyebrow">YOUR COMPETITIONS</span><h2>Choose your stage</h2></div><button className="text-btn" onClick={() => setPage('Leagues')}>View all ↗</button></div>
        <div className="competition-grid">{competitions.map(c => <button className={`competition-card ${selected === c.code ? 'chosen' : ''}`} key={c.code} onClick={() => { setSelected(c.code); setPage(c.type === 'Europe' ? 'Europe' : 'Leagues') }}><span className="comp-icon">{c.type === 'Europe' ? '✦' : '⚽'}</span><span className="comp-type">{c.country} · {c.type}</span><strong>{c.name}</strong><span className="card-arrow">↗</span></button>)}</div>
      </section>}
      {page === 'Leagues' && <section><SectionIntro title="League centre" subtitle="Real tables stay separate from your simulated universe."/><CompetitionSelect competitions={competitions} selected={selected} setSelected={setSelected}/><div className="panel"><PanelHeader title={`${current?.name || 'Competition'} table`}><div className="switch"><button className={tab === 'real' ? 'selected' : ''} onClick={() => setTab('real')}>Real table</button><button className={tab === 'sim' ? 'selected' : ''} onClick={() => setTab('sim')}>Simulated</button></div></PanelHeader>{loading ? <Empty>Loading official data…</Empty> : error ? <Empty>{error}</Empty> : <LeagueTable rows={tab === 'real' ? realTable.map(r => ({ ...r, name: r.team.name, id: r.team.id })) : simulatedTable} code={selected} simulated={tab === 'sim'}/>}</div></section>}
      {page === 'Fixtures' && <section><SectionIntro title="Fixture list" subtitle="Expand a matchday, enter score predictions and watch your table change."/><CompetitionSelect competitions={competitions} selected={selected} setSelected={setSelected}/>{loading ? <Empty>Loading fixtures…</Empty> : error ? <Empty>{error}</Empty> : matchdays.length ? <div className="matchday-list">{matchdays.map(([day, list]) => <details className="matchday" key={day} open><summary><span>{day}</span><small>{list.length} matches</small><b>⌄</b></summary><div className="match-list">{list.map(m => <MatchCard key={m.id} match={m} prediction={store.predictions[m.id]} onChange={setPrediction} onClear={clearPrediction}/>)}</div></details>)}</div> : <Empty>No fixture dataset loaded for this competition. Import a verified dataset in Settings.</Empty>}</section>}
      {page === 'Cups' && <section><SectionIntro title="Domestic cups" subtitle="Cup competitions use the same match and prediction engine."/><div className="cup-grid">{['FA Cup','Carabao Cup','EFL Trophy','FA Trophy'].map((name,i)=><div className="cup-card" key={name}><span className="cup-number">0{i+1}</span><div><h3>{name}</h3><p>Import its verified fixtures to simulate rounds and results.</p></div><button className="small-btn" onClick={() => { setShowImport(true); setImportText('') }}>Add dataset ↗</button></div>)}</div><div className="info-panel"><b>How cup datasets work</b><p>Import a competition JSON containing teams and matches. Finished scores are treated as real results; scheduled matches accept predictions. No imaginary cup draws quietly appear behind your back.</p></div></section>}
      {page === 'Europe' && <section><SectionIntro title="European football" subtitle="Continental competitions, league phases and your alternate outcomes."/><CompetitionSelect competitions={competitions.filter(c => c.type === 'Europe')} selected={selected} setSelected={setSelected}/><div className="panel"><PanelHeader title={current?.name || 'European competition'}/>{loading ? <Empty>Loading European data…</Empty> : error ? <Empty>{error}</Empty> : <LeagueTable rows={tab === 'real' ? realTable.map(r => ({ ...r, name: r.team.name, id: r.team.id })) : simulatedTable} code={selected} simulated={false}/>}</div><div className="info-panel"><b>European qualification zones</b><p>For Champions League and Europa League league-phase tables: positions 1–8 direct qualification, 9–24 knockout play-offs, 25–36 eliminated.</p></div></section>}
      {page === 'History' && <section><SectionIntro title="Universe history" subtitle="Saved snapshots of your simulated tables."/><div className="history-list">{store.history.length ? store.history.map((h,i)=><div className="history-card" key={`${h.date}-${i}`}><div><b>{h.competition} · {h.season}</b><small>{new Date(h.date).toLocaleString('en-GB')}</small></div><span>{h.table.length} clubs</span></div>) : <Empty>No saved snapshots yet. Save one from a league table.</Empty>}</div><button className="primary-btn" onClick={simulateSeason}>Save current table snapshot</button></section>}
      {page === 'Settings' && <section><SectionIntro title="Universe settings" subtitle="Manage your season, datasets and local backup."/><div className="settings-grid"><div className="panel setting-panel"><h3>Season</h3><p>Label your current universe season.</p><input value={store.season} onChange={e => setStore(s => ({...s, season:e.target.value}))}/></div><div className="panel setting-panel"><h3>Data import</h3><p>Add verified lower-league and cup fixtures not available through your API plan.</p><button className="primary-btn" onClick={() => setShowImport(v => !v)}>Import competition JSON</button></div><div className="panel setting-panel"><h3>Backup</h3><p>Download your predictions, imported data and history.</p><button className="secondary-btn" onClick={exportData}>Export backup</button></div><div className="panel setting-panel danger-panel"><h3>Reset universe</h3><p>Delete all local predictions, imported competitions and history.</p><button className="danger-btn" onClick={resetUniverse}>Reset everything</button></div></div>
        {showImport && <div className="panel import-panel"><PanelHeader title="Import verified dataset"><button className="close-btn" onClick={() => setShowImport(false)}>×</button></PanelHeader><p>Paste JSON using the format below. Team IDs must be unique within each competition.</p><pre>{`{
  "competitions": [{
    "id": "FAC",
    "name": "FA Cup",
    "country": "England",
    "type": "Cup",
    "teams": [{"id": 1, "name": "Example FC"}],
    "matches": [{
      "id": "FAC-1", "date": "2026-11-07",
      "status": "SCHEDULED",
      "homeId": 1, "home": "Example FC",
      "awayId": 2, "away": "Other FC"
    }]
  }]
}`}</pre><textarea value={importText} onChange={e => setImportText(e.target.value)} placeholder="Paste dataset JSON here…"/><button className="primary-btn" onClick={importDataset}>Import dataset</button></div>}
      </section>}
      <footer>FOOTBALLVERSE <span>·</span> Built for the beautiful game.</footer>
    </main>
  </div>
}

function Stat({label,value,detail}) { return <div className="stat-card"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div> }
function SectionIntro({title,subtitle}) { return <div className="section-intro"><h2>{title}</h2><p>{subtitle}</p></div> }
function PanelHeader({title,children}) { return <div className="panel-header"><h3>{title}</h3>{children}</div> }
function Empty({children}) { return <div className="empty-state">{children}</div> }
function CompetitionSelect({competitions,selected,setSelected}) { return <div className="competition-select"><label>COMPETITION</label><select value={selected} onChange={e => setSelected(e.target.value)}>{competitions.map(c=><option key={c.code} value={c.code}>{c.name}</option>)}</select></div> }
function LeagueTable({rows,code,simulated}) {
  if (!rows.length) return <Empty>No table data returned. This may be an API-plan limitation or an unimported dataset.</Empty>
  return <div className="table-wrap"><table><thead><tr><th>#</th><th>CLUB</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GD</th><th>PTS</th></tr></thead><tbody>{rows.map((r,i)=><tr key={r.id || r.name} className={zoneClass(code,i+1)}><td>{i+1}</td><td className="club-name">{r.name}</td><td>{r.played ?? r.playedGames ?? 0}</td><td>{r.won ?? 0}</td><td>{r.drawn ?? 0}</td><td>{r.lost ?? 0}</td><td>{r.gd ?? r.goalDifference ?? 0}</td><td className="points">{r.points ?? 0}</td></tr>)}</tbody></table><div className="table-foot">{simulated ? 'Based on completed results and saved predictions.' : 'Official data supplied by football-data.org.'}</div></div>
}
function MatchCard({match,prediction,onChange,onClear}) {
  const done = match.status === 'FINISHED'
  return <div className="match-card"><div className="match-date">{dateLabel(match.utcDate)}<small>{done ? 'FULL TIME' : match.status === 'IN_PLAY' ? 'LIVE' : 'UPCOMING'}</small></div><div className="match-teams"><strong>{match.homeTeam.name}</strong><span className="actual-score">{done ? score(match) : 'vs'}</span><strong>{match.awayTeam.name}</strong></div>{!done && <div className="prediction-box"><div className="prediction-inputs"><input aria-label="Home score prediction" inputMode="numeric" value={prediction?.home ?? ''} placeholder="-" onChange={e=>onChange(match.id,'home',e.target.value)}/><span>:</span><input aria-label="Away score prediction" inputMode="numeric" value={prediction?.away ?? ''} placeholder="-" onChange={e=>onChange(match.id,'away',e.target.value)}/></div><button className="clear-prediction" onClick={()=>onClear(match.id)} title="Clear prediction">×</button></div>}</div>
}
